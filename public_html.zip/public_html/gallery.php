<?php include('header.php'); ?>

        <!-- Page Header Start -->
        <div class="container-fluid bg-dark p-5">
            <div class="row">
                <div class="col-12 text-center">
                    <h1 class="display-4 text-white">Gallery</h1>
                    <hr class="w-25 mx-auto bg-primary">
                </div>
            </div>
        </div>
        <!-- Page Header End -->

    <!-- gallery Start -->
    <div class="container-fluid py-4 px-4" id="Galery">
        <div class="row g-3">
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-1.jpeg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-2.jpeg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-3.jpeg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-6.jpeg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-4.jpeg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-5.jpeg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-7.jpeg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-8.jpeg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-9.jpeg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-10.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-11.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-12.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-13.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-14.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-15.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-m-6 small-2">
                <div class="blog-item">
                    <div class="position-relative overflow-hidden">
                        <img class="img-fluid" src="img/blog-16.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- gallery End -->
    
       

    <?php include('footer.php'); ?>
