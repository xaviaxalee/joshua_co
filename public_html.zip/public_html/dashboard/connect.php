<?php
session_start();
$conn = mysqli_connect("localhost","root","","joshuaco")
        or die("Couldn't connect to database");
?>


