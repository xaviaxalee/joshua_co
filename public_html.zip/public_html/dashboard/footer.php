<div class="py-4 text-center" style="background-color: #001f3f;
        color: #fff;">
   <p class="m-0"> 
    Copyright 
    <script>document.write(new Date().getFullYear());</script> © All Right Reserved 
  </p>
</div>
<script src="script.js"> </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function toggleNav() {
        const nav = document.getElementById('nav-menu');
        nav.classList.toggle('show');
    }
</script>
</body>
</html>