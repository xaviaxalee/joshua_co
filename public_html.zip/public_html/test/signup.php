<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
</head>
<body>
    <form action="process_signup.php" method="POST">
        <h2>Signup</h2>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <button type="submit">Signup</button>
    </form>
</body>
</html>
